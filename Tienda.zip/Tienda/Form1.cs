﻿using Microsoft.Data.Sqlite;
using System.Data;
using System.Data.SQLite;


namespace Tienda
{
    public partial class Form1 : Form
    {
        private string cadenaConexion = "Data Source=DB\\Inventario.db";
        private ContextMenuStrip menuDetalleVenta;
        private ContextMenuStrip menuProductos;



        public Form1()
        {
            InitializeComponent();

            // Apariencia general
            this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            this.Size = new Size(1200, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.MinimumSize = new Size(1000, 650);


            // === Inicializar interfaces (crean controles) ===
            InicializarVentas();
            ConfigurarDetalleVenta();

            // === Conectar eventos (YA EXISTEN LOS CONTROLES) ===
            btnGuardarProducto.Click += BtnGuardarProducto_Click;
            btnActualizarProducto.Click += BtnActualizarProducto_Click;

            btnGuardarCliente.Click += BtnGuardarCliente_Click;
            btnActualizarCliente.Click += BtnActualizarCliente_Click;

            cmbProductos.SelectedIndexChanged += cmbProductos_SelectedIndexChanged;
            btnAgregarProducto.Click += btnAgregarProducto_Click;

            btnGuardarVenta.Click += btnGuardarVenta_Click;
            btnPagarVenta.Click += btnPagarVenta_Click;

            dgvProductos.CellClick += dgvProductos_CellClick;
            dgvClientes.CellClick += dgvClientes_CellClick;


            // === Base de datos ===
            CrearTablas();

            // === Cargas iniciales ===
            CargarProductos();
            CargarClientes();
       
            CargarInventario();
            CargarClientesCombo();
            CargarProductosCombo();
                
            CargarVentasPendientes();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        

        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);

            AjustarSplitContainers();
        }


        private void AjustarSplitContainers()
        {
            AjustarSplit(tabProductos);
            AjustarSplit(tabClientes);
            AjustarSplit(tabVentas);
        }

        private void AjustarSplit(TabPage tab)
        {
            foreach (Control c in tab.Controls)
            {
                if (c is SplitContainer split)
                {
                    // 30% formulario / 70% grilla
                    split.SplitterDistance = (int)(split.Width * 0.30);
                }
            }
        }

        private void cmbProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProductos.SelectedItem == null) return;

            DataRowView fila = (DataRowView)cmbProductos.SelectedItem;
            int stock = Convert.ToInt32(fila["Stock"]);

            lblStockDisponible.Text = $"Stock: {stock}";
        }

        private void CrearTablas()
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"

        CREATE TABLE IF NOT EXISTS Productos (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nombre TEXT NOT NULL,
            Precio REAL NOT NULL,
            Stock INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS Clientes (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nombre TEXT NOT NULL,
            Documento TEXT
        );

        CREATE TABLE IF NOT EXISTS Ventas (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            ClienteId INTEGER NOT NULL,
            Fecha TEXT NOT NULL,
            Total REAL NOT NULL,
            Estado INTEGER NOT NULL,
            OrdenId INTEGER
        
        );

        CREATE TABLE IF NOT EXISTS VentaDetalle (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            VentaId INTEGER NOT NULL,
            ProductoId INTEGER NOT NULL,
            Cantidad INTEGER NOT NULL,
            Precio REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS Orden (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            NumeroOrden INTEGER NOT NULL UNIQUE,
            Fecha TEXT NOT NULL,
            Estado INTEGER NOT NULL
        );

        ";

                cmd.ExecuteNonQuery();
            }
        }

        private void CargarInventario()
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Nombre, Stock FROM Productos";

                var dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                dgvInventario.DataSource = dt;

                int total = 0;
                foreach (DataRow row in dt.Rows)
                {
                    total += Convert.ToInt32(row["Stock"]);
                }

                lblTotalProductos.Text = $"Total productos: {total}";
            }
        }
        private void CargarProductosCombo()
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, Nombre, Stock FROM Productos";

                var dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                cmbProductos.DataSource = dt;
                cmbProductos.DisplayMember = "Nombre";
                cmbProductos.ValueMember = "Id";
                cmbProductos.SelectedIndex = -1;
            }
        }

        private void CargarClientesCombo()
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, Nombre FROM Clientes";

                var dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                cmbClientes.DataSource = dt;
                cmbClientes.DisplayMember = "Nombre";
                cmbClientes.ValueMember = "Id";
                cmbClientes.SelectedIndex = -1; // nada seleccionado
            }
        }


        private void BtnGuardarProducto_Click(object sender, EventArgs e)
        {
            using (var con = new Microsoft.Data.Sqlite.SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"
            INSERT INTO Productos (Nombre, Precio, Stock)
            VALUES ($nombre, $precio, $stock);
        ";
                cmd.Parameters.AddWithValue("$nombre", txtNombreProducto.Text);
                cmd.Parameters.AddWithValue("$precio", nudPrecio.Value);
                cmd.Parameters.AddWithValue("$stock", nudStock.Value);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("✅ Producto guardado");
            CargarProductos();
            LimpiarProducto();


            CargarInventario();
            CargarClientesCombo();
            CargarProductosCombo();

        }

        private void BtnActualizarProducto_Click(object sender, EventArgs e)
        {
            if (dgvProductos.CurrentRow == null) return;

            int id = Convert.ToInt32(dgvProductos.CurrentRow.Cells["Id"].Value);

            using (var con = new Microsoft.Data.Sqlite.SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"
            UPDATE Productos
            SET Nombre=$nombre, Precio=$precio, Stock=$stock
            WHERE Id=$id;
        ";
                cmd.Parameters.AddWithValue("$nombre", txtNombreProducto.Text);
                cmd.Parameters.AddWithValue("$precio", nudPrecio.Value);
                cmd.Parameters.AddWithValue("$stock", nudStock.Value);
                cmd.Parameters.AddWithValue("$id", id);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("✏️ Producto actualizado");
            CargarProductos();
            LimpiarProducto();
        }

        private void MostrarRutaBD()
        {
            MessageBox.Show(
                System.IO.Path.GetFullPath("DB\\Inventario.db"),
                "Ruta REAL de la BD"
            );
        }

        private void VerTablas()
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = "SELECT name FROM sqlite_master WHERE type='table';";

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        MessageBox.Show(reader.GetString(0), "Tabla encontrada");
                    }
                }
            }
        }

        private void CargarProductos()
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, Nombre, Precio, Stock FROM Productos";

                var dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                dgvProductos.DataSource = dt;
                dgvProductos.Columns["Id"].Visible = false;
            }
        }


        private void BtnActualizarCliente_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow == null) return;

            int id = Convert.ToInt32(dgvClientes.CurrentRow.Cells["Id"].Value);

            using (var con = new Microsoft.Data.Sqlite.SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"
            UPDATE Clientes
            SET Nombre=$nombre, Documento=$doc
            WHERE Id=$id;
        ";
                cmd.Parameters.AddWithValue("$nombre", txtNombreCliente.Text);
                cmd.Parameters.AddWithValue("$doc", txtDocumento.Text);
                cmd.Parameters.AddWithValue("$id", id);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("✏️ Cliente actualizado");
            CargarClientes();
            LimpiarCliente();
            CargarClientesCombo();
        }

        private void BtnGuardarCliente_Click(object sender, EventArgs e)
        {
            using (var con = new Microsoft.Data.Sqlite.SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"
            INSERT INTO Clientes (Nombre, Documento)
            VALUES ($nombre, $doc);
        ";
                cmd.Parameters.AddWithValue("$nombre", txtNombreCliente.Text);
                cmd.Parameters.AddWithValue("$doc", txtDocumento.Text);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("✅ Cliente guardado");
            CargarClientes();
            LimpiarCliente();
            CargarClientesCombo();
        }

        private void CargarClientes()
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, Nombre, Documento FROM Clientes";

                var dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                dgvClientes.DataSource = dt;
                dgvClientes.Columns["Id"].Visible = false;
            }
        }

        private void ConfigurarDetalleVenta()
        {
            dgvDetalleVenta.Columns.Clear();
            dgvDetalleVenta.AutoGenerateColumns = false;

            dgvDetalleVenta.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ProductoId",
                HeaderText = "ProductoId",
                Visible = false
            });

            dgvDetalleVenta.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Producto",
                HeaderText = "Producto"
            });

            dgvDetalleVenta.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Precio",
                HeaderText = "Precio"
            });

            dgvDetalleVenta.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Cantidad",
                HeaderText = "Cantidad"
            });

            dgvDetalleVenta.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Subtotal",
                HeaderText = "Subtotal"
            });

            dgvDetalleVenta.ReadOnly = true;
            dgvDetalleVenta.AllowUserToAddRows = false;
            dgvDetalleVenta.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            if (cmbProductos.SelectedItem == null)
            {
                MessageBox.Show("Selecciona un producto");
                return;
            }

            int cantidad = (int)nudCantidad.Value;
            if (cantidad <= 0)
            {
                MessageBox.Show("Cantidad inválida");
                return;
            }

            DataRowView fila = (DataRowView)cmbProductos.SelectedItem;

            int productoId = Convert.ToInt32(fila["Id"]);
            string nombre = fila["Nombre"].ToString();
            int stock = Convert.ToInt32(fila["Stock"]);
            decimal precio = ObtenerPrecioProducto(productoId);

            // ✅ Validar inventario
            if (cantidad > stock)
            {
                MessageBox.Show("No hay stock suficiente");
                return;
            }

            decimal subtotal = precio * cantidad;

            dgvDetalleVenta.Rows.Add(
                productoId,
                nombre,
                precio,
                cantidad,
                subtotal
            );

            CalcularTotalVenta();
        }

        private decimal ObtenerPrecioProducto(int productoId)
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Precio FROM Productos WHERE Id = $id";
                cmd.Parameters.AddWithValue("$id", productoId);

                return Convert.ToDecimal(cmd.ExecuteScalar());
            }
        }

        private void CalcularTotalVenta()
        {
            decimal total = 0;

            foreach (DataGridViewRow row in dgvDetalleVenta.Rows)
            {
                total += Convert.ToDecimal(row.Cells["Subtotal"].Value);
            }

            lblTotal.Text = $"Total: {total:C}";
        }

        private void btnNuevaVenta_Click(object sender, EventArgs e)
        {
            // Limpiar selección de ventas pendientes
            dgvVentasPendientes.ClearSelection();

            // Limpiar detalle de productos
            dgvDetalleVenta.Rows.Clear();

            // Resetear venta actual
            ventaActualId = 0;

            // Limpiar combos
            cmbClientes.SelectedIndex = -1;
            cmbProductos.SelectedIndex = -1;

            // Resetear cantidad
            nudCantidad.Value = 1;

            // Resetear stock mostrado
            lblStockDisponible.Text = "Stock: -";

            // Resetear estado y total
            lblEstadoVenta.Text = "Estado: Nueva";
            lblEstadoVenta.ForeColor = Color.DimGray;

            lblTotal.Text = "Total: $0.00";

            // Habilitar controles para nueva venta
            cmbClientes.Enabled = true;
            cmbProductos.Enabled = true;
            nudCantidad.Enabled = true;
            btnAgregarProducto.Enabled = true;
        }

        private int ventaActualId = 0; // Id de la venta activa

        private void btnGuardarVenta_Click(object sender, EventArgs e)
        {
            if (cmbClientes.SelectedValue == null)
            {
                MessageBox.Show("Seleccione un cliente");
                return;
            }

            if (dgvDetalleVenta.Rows.Count == 0)
            {
                MessageBox.Show("Agregue al menos un producto");
                return;
            }

            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();
                using (var tx = con.BeginTransaction())
                {
                    int ordenId = CrearOrden(con);

                    var cmdVenta = con.CreateCommand();
                    cmdVenta.CommandText = @"
            INSERT INTO Ventas (ClienteId, Fecha, Total, Estado, OrdenId)
            VALUES ($cliente, $fecha, $total, 0, $OrdenId);
            SELECT last_insert_rowid();
        ";

                    cmdVenta.Parameters.AddWithValue("$cliente", cmbClientes.SelectedValue);
                    cmdVenta.Parameters.AddWithValue("$fecha", DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                    cmdVenta.Parameters.AddWithValue("$total", ObtenerTotalVenta());
                    cmdVenta.Parameters.AddWithValue("$OrdenId", ordenId);

                    ventaActualId = Convert.ToInt32(cmdVenta.ExecuteScalar());

                    // Detalle
                    foreach (DataGridViewRow row in dgvDetalleVenta.Rows)
                    {
                        var cmdDet = con.CreateCommand();
                        cmdDet.CommandText = @"
                INSERT INTO VentaDetalle (VentaId, ProductoId, Cantidad, Precio)
                VALUES ($venta, $producto, $cantidad, $precio);
            ";
                        cmdDet.Parameters.AddWithValue("$venta", ventaActualId);
                        cmdDet.Parameters.AddWithValue("$producto", row.Cells["ProductoId"].Value);
                        cmdDet.Parameters.AddWithValue("$cantidad", row.Cells["Cantidad"].Value);
                        cmdDet.Parameters.AddWithValue("$precio", row.Cells["Precio"].Value);
                        cmdDet.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
            }

            lblEstadoVenta.Text = "Estado: Abierta";
            CargarVentasPendientes();
            MessageBox.Show("✅ Venta guardada (pendiente de pago)");
        }

        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // ✅ Validar índice de fila
            if (e.RowIndex < 0) return;

            DataGridViewRow fila = dgvProductos.Rows[e.RowIndex];

            // ✅ Validar y asignar Nombre
            if (fila.Cells["Nombre"]?.Value != null)
                txtNombreProducto.Text = fila.Cells["Nombre"].Value.ToString();
            else
                txtNombreProducto.Clear();

            // ✅ Validar y asignar Precio
            if (fila.Cells["Precio"]?.Value != null &&
                decimal.TryParse(fila.Cells["Precio"].Value.ToString(), out decimal precio))
                nudPrecio.Value = precio;
            else
                nudPrecio.Value = 0;

            // ✅ Validar y asignar Stock
            if (fila.Cells["Stock"]?.Value != null &&
                int.TryParse(fila.Cells["Stock"].Value.ToString(), out int stock))
                nudStock.Value = stock;
            else
                nudStock.Value = 0;
        }
        private int CrearOrden(SqliteConnection con)
        {
            var cmd = con.CreateCommand();

            cmd.CommandText = @"
                 INSERT INTO Orden (NumeroOrden, Fecha, Estado)
            VALUES (
                IFNULL((SELECT MAX(NumeroOrden) FROM Orden), 0) + 1,
                $fecha,
                0
            );
            SELECT last_insert_rowid();

    ";

            cmd.Parameters.AddWithValue("$fecha", DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            return Convert.ToInt32(cmd.ExecuteScalar());
        }

        private decimal ObtenerTotalVenta()
        {
            decimal total = 0;
            foreach (DataGridViewRow row in dgvDetalleVenta.Rows)
                total += Convert.ToDecimal(row.Cells["Subtotal"].Value);
            return total;
        }

        private void btnPagarVenta_Click(object sender, EventArgs e)
        {
            if (ventaActualId == 0)
            {
                MessageBox.Show("Primero guarde la venta");
                return;
            }

            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();
                using (var tx = con.BeginTransaction())
                {
                    // 1️⃣ Descontar stock
                    foreach (DataGridViewRow row in dgvDetalleVenta.Rows)
                    {
                        var cmdStock = con.CreateCommand();
                        cmdStock.CommandText = @"
                    UPDATE Productos
                    SET Stock = Stock - $cantidad
                    WHERE Id = $producto;
                ";
                        cmdStock.Parameters.AddWithValue("$cantidad", row.Cells["Cantidad"].Value);
                        cmdStock.Parameters.AddWithValue("$producto", row.Cells["ProductoId"].Value);
                        cmdStock.ExecuteNonQuery();
                    }

                    // 2️⃣ Marcar venta como pagada
                    var cmdVenta = con.CreateCommand();
                    cmdVenta.CommandText = "UPDATE Ventas SET Estado = 1 WHERE Id = $id;";
                    cmdVenta.Parameters.AddWithValue("$id", ventaActualId);
                    cmdVenta.ExecuteNonQuery();

                    tx.Commit();
                }
            }

            CargarVentasPendientes();
            lblEstadoVenta.Text = "Estado: Pagada";
            MessageBox.Show("💰 Venta pagada correctamente");

            // Limpiar
            dgvDetalleVenta.Rows.Clear();
            ventaActualId = 0;
            CargarVentasPendientes();
            CargarInventario();
        }

        private void ConfigurarVentasPendientes()
        {
            dgvVentasPendientes = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };

            dgvVentasPendientes.CellClick += dgvVentasPendientes_CellClick;
        }

        private void CargarVentasPendientes()
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"
                  SELECT
                    O.NumeroOrden,
                    C.Nombre AS Cliente,
                    C.Documento,
                    V.Fecha,
                    V.Total
                FROM Ventas V
                INNER JOIN Orden O ON O.Id = V.Id
                INNER JOIN Clientes C ON C.Id = V.ClienteId
                WHERE V.Estado = 0
                ORDER BY O.Id DESC;

        ";

                var dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                dgvVentasPendientes.DataSource = dt;
                dgvVentasPendientes.Columns["NumeroOrden"].Visible = false;
            }
        }

        private void dgvVentasPendientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            ventaActualId = Convert.ToInt32(
                dgvVentasPendientes.Rows[e.RowIndex].Cells["NumeroOrden"].Value
            );

            CargarDetalleVenta(ventaActualId);
            lblEstadoVenta.Text = "Estado: Pendiente";
        }

        private void CargarDetalleVenta(int ventaId)
        {
            dgvDetalleVenta.Rows.Clear();

            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"
            SELECT 
                D.ProductoId,
                P.Nombre,
                D.Precio,
                D.Cantidad,
                (D.Precio * D.Cantidad) AS Subtotal
            FROM VentaDetalle D
            INNER JOIN Productos P ON P.Id = D.ProductoId
            WHERE D.VentaId = $venta;
        ";
                cmd.Parameters.AddWithValue("$venta", ventaId);

                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        dgvDetalleVenta.Rows.Add(
                            rd["ProductoId"],
                            rd["Nombre"],
                            rd["Precio"],
                            rd["Cantidad"],
                            rd["Subtotal"]
                        );
                    }
                }
            }

            CalcularTotalVenta();
        }

        private void EliminarProductoGrid_Click(object sender, EventArgs e)
        {
            if (dgvProductos.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un producto");
                return;
            }

            int idProducto = Convert.ToInt32(
                dgvProductos.CurrentRow.Cells["Id"].Value
            );

            DialogResult r = MessageBox.Show(
                "¿Desea eliminar este producto?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (r != DialogResult.Yes) return;

            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();
                var cmd = con.CreateCommand();
                cmd.CommandText = "DELETE FROM Productos WHERE Id = $id";
                cmd.Parameters.AddWithValue("$id", idProducto);
                cmd.ExecuteNonQuery();
            }

            CargarProductos();
            LimpiarProducto();
        }

        private void EliminarProducto_Click(object sender, EventArgs e)
        {
            if (dgvDetalleVenta.CurrentRow == null)
                return;

            DialogResult r = MessageBox.Show(
                "¿Desea eliminar este producto de la venta?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (r == DialogResult.Yes)
            {
                dgvDetalleVenta.Rows.Remove(dgvDetalleVenta.CurrentRow);
                CalcularTotalVenta();
            }
        }

        private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // ✅ Validar índice de fila
            if (e.RowIndex < 0) return;

            DataGridViewRow fila = dgvClientes.Rows[e.RowIndex];

            // ✅ Validar y asignar Nombre
            if (fila.Cells["Nombre"]?.Value != null)
                txtNombreCliente.Text = fila.Cells["Nombre"].Value.ToString();
            else
                txtNombreCliente.Clear();

            // ✅ Validar y asignar Documento
            if (fila.Cells["Documento"]?.Value != null)
                txtDocumento.Text = fila.Cells["Documento"].Value.ToString();
            else
                txtDocumento.Clear();
        }


        private void LimpiarCliente()
        {
            txtNombreCliente.Clear();
            txtDocumento.Clear();
        }

        private void LimpiarProducto()
        {
            txtNombreProducto.Clear();
            nudPrecio.Value = 0;
            nudStock.Value = 0;
        }

        private void btnVerVentas_Click(object sender, EventArgs e)
        {
            FrmVentasEstado frm = new FrmVentasEstado();
            frm.ShowDialog();
        }

    }
}
