﻿using Microsoft.Data.Sqlite;
using System.Data;

namespace Tienda
{
    public partial class FrmVentasEstado : Form
    {
        private string cadenaConexion = "Data Source=DB\\Inventario.db";

        public FrmVentasEstado()
        {
            InitializeComponent();

            // Llenar combo
            cmbEstado.Items.Add("Pendientes");
            cmbEstado.Items.Add("Pagadas");
            cmbEstado.SelectedIndex = 0;

            cmbEstado.SelectedIndexChanged += CmbEstado_SelectedIndexChanged;
            dgvVentas.CellClick += dgvVentas_CellClick;


            // Cargar inicialmente pendientes
            CargarVentas(0);
        }

        private void dgvVentas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            int ventaId = Convert.ToInt32(
                dgvVentas.Rows[e.RowIndex].Cells["Id"].Value
            );

            CargarDetalleVenta(ventaId);
        }

        private void CargarDetalleVenta(int ventaId)
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"
            SELECT
                P.Nombre AS Producto,
                D.Cantidad,
                D.Precio,
                (D.Cantidad * D.Precio) AS Subtotal
            FROM VentaDetalle D
            INNER JOIN Productos P ON P.Id = D.ProductoId
            WHERE D.VentaId = $venta;
        ";
                cmd.Parameters.AddWithValue("$venta", ventaId);

                var dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                dgvDetalleVenta.DataSource = dt;
            }
        }
        private void CmbEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            int estado = cmbEstado.SelectedIndex == 0 ? 0 : 1;
            CargarVentas(estado);
        }

        private void CargarVentas(int estado)
        {
            using (var con = new SqliteConnection(cadenaConexion))
            {
                con.Open();

                var cmd = con.CreateCommand();
                cmd.CommandText = @"
                    SELECT 
                        V.Id,
                        C.Nombre AS Cliente,
                        V.Fecha,
                        V.Total
                    FROM Ventas V
                    INNER JOIN Clientes C ON C.Id = V.ClienteId
                    WHERE V.Estado = $estado
                ";
                cmd.Parameters.AddWithValue("$estado", estado);

                var dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                dgvVentas.DataSource = dt;
            }
        }
    }
}
