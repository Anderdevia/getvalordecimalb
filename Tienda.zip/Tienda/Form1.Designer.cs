﻿namespace Tienda
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblTotal;

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabProductos;
        private System.Windows.Forms.TabPage tabClientes;
        private System.Windows.Forms.TabPage tabVentas;
        private System.Windows.Forms.TabPage tabInventario;

        // PRODUCTOS
        private System.Windows.Forms.TextBox txtNombreProducto;
        private System.Windows.Forms.NumericUpDown nudPrecio;
        private System.Windows.Forms.NumericUpDown nudStock;
        private System.Windows.Forms.Button btnGuardarProducto;
        private System.Windows.Forms.Button btnActualizarProducto;
        private System.Windows.Forms.DataGridView dgvProductos;

        // CLIENTES
        private System.Windows.Forms.TextBox txtNombreCliente;
        private System.Windows.Forms.TextBox txtDocumento;
        private System.Windows.Forms.Button btnGuardarCliente;
        private System.Windows.Forms.Button btnActualizarCliente;
        private System.Windows.Forms.DataGridView dgvClientes;

        // VENTAS
        private System.Windows.Forms.ComboBox cmbClientes;
        private System.Windows.Forms.ComboBox cmbProductos;
        private System.Windows.Forms.NumericUpDown nudCantidad;
        private System.Windows.Forms.Label lblStockDisponible;
        private System.Windows.Forms.Label lblEstadoVenta;
        private System.Windows.Forms.Button btnAgregarProducto;
        private System.Windows.Forms.Button btnGuardarVenta;
        private System.Windows.Forms.Button btnPagarVenta;
        private System.Windows.Forms.DataGridView dgvDetalleVenta;

        // INVENTARIO
        private System.Windows.Forms.DataGridView dgvInventario;
        private System.Windows.Forms.Label lblTotalProductos;
        private System.Windows.Forms.DataGridView dgvVentasPendientes;




        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.Font = new System.Drawing.Font("Segoe UI", 10F);

            tabControl1 = new System.Windows.Forms.TabControl();
            tabProductos = new System.Windows.Forms.TabPage("Productos");
            tabClientes = new System.Windows.Forms.TabPage("Clientes");
            tabVentas = new System.Windows.Forms.TabPage("Ventas");
            tabInventario = new System.Windows.Forms.TabPage("Inventario");

            tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            tabControl1.Controls.AddRange(new[] {
                tabProductos, tabClientes, tabVentas, tabInventario
            });

            InicializarProductos();
            InicializarClientes();
         
            InicializarInventario();
            InicializarVentas();
            this.Controls.Add(tabControl1);
            this.Text = "Sistema de Inventario y Ventas";
         
        }

        // ================= PRODUCTOS =================
        private void InicializarProductos()
        {
            SplitContainer split = CrearSplit();

            var panel = CrearFormulario("Gestión de Productos");

            txtNombreProducto = new TextBox { Dock = DockStyle.Fill };
            nudPrecio = new NumericUpDown
            {
                DecimalPlaces = 2,
                Minimum = 0,
                Maximum = 1000000,   // ✅ evita que se limite a 100
                Increment = 0.01M,   // ✅ incremento de centavos
                Dock = DockStyle.Fill,
                ThousandsSeparator = true
            };
            nudStock = new NumericUpDown { Dock = DockStyle.Fill };

            btnGuardarProducto = CrearBoton("Guardar");
            btnActualizarProducto = CrearBoton("Actualizar");

            panel.Controls.AddRange(new System.Windows.Forms.Control[]
            {
                Etiqueta("Nombre del producto"), txtNombreProducto,
                Etiqueta("Precio"), nudPrecio,
                Etiqueta("Stock"), nudStock,
                btnGuardarProducto,
                btnActualizarProducto
            });

            dgvProductos = CrearGrid();

            split.Panel1.Controls.Add(panel);
            split.Panel2.Controls.Add(dgvProductos);
            tabProductos.Controls.Add(split);

            menuProductos = new ContextMenuStrip();

            ToolStripMenuItem eliminarProducto = new ToolStripMenuItem("Eliminar producto");
            eliminarProducto.Click += EliminarProductoGrid_Click;

            menuProductos.Items.Add(eliminarProducto);
            dgvProductos.ContextMenuStrip = menuProductos;
        }

        // ================= CLIENTES =================
        private void InicializarClientes()
        {
            SplitContainer split = CrearSplit();

            var panel = CrearFormulario("Gestión de Clientes");

            txtNombreCliente = new TextBox { Dock = DockStyle.Fill };
            txtDocumento = new TextBox { Dock = DockStyle.Fill };

            btnGuardarCliente = CrearBoton("Guardar");
            btnActualizarCliente = CrearBoton("Actualizar");

            panel.Controls.AddRange(new System.Windows.Forms.Control[]
            {
                Etiqueta("Nombre"), txtNombreCliente,
                Etiqueta("Documento"), txtDocumento,
                btnGuardarCliente,
                btnActualizarCliente
            });

            dgvClientes = CrearGrid();

            split.Panel1.Controls.Add(panel);
            split.Panel2.Controls.Add(dgvClientes);
            tabClientes.Controls.Add(split);
        }

        // ================= VENTAS =================
        private void InicializarVentas()
        {
            // Split principal
            SplitContainer split = CrearSplit();
            split.SplitterDistance = 480;

            // ==================================================
            // PANEL IZQUIERDO
            // ==================================================
            var panelIzquierdo = CrearFormulario("Nueva / Gestión de Venta");

            // ========= NUEVA VENTA =========
            panelIzquierdo.Controls.Add(Etiqueta("Cliente"));
            cmbClientes = new ComboBox
            {
                Dock = DockStyle.Top,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            panelIzquierdo.Controls.Add(cmbClientes);

            panelIzquierdo.Controls.Add(Etiqueta("Producto"));
            cmbProductos = new ComboBox
            {
                Dock = DockStyle.Top,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            panelIzquierdo.Controls.Add(cmbProductos);

            lblStockDisponible = new Label
            {
                Text = "Stock: -",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Dock = DockStyle.Top
            };
            panelIzquierdo.Controls.Add(lblStockDisponible);

            nudCantidad = new NumericUpDown
            {
                Dock = DockStyle.Top,
                Minimum = 1,
                Maximum = 100000
            };
            panelIzquierdo.Controls.Add(nudCantidad);

            btnAgregarProducto = CrearBoton("Agregar Producto");
            panelIzquierdo.Controls.Add(btnAgregarProducto);

            // ========= SEPARADOR =========
            panelIzquierdo.Controls.Add(new Label
            {
                Text = "Ventas Pendientes",
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Padding = new Padding(0, 15, 0, 5)
            });

            // ========= GRID VENTAS PENDIENTES =========
            dgvVentasPendientes = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AllowUserToAddRows = false
            };
            dgvVentasPendientes.CellClick += dgvVentasPendientes_CellClick;
            panelIzquierdo.Controls.Add(dgvVentasPendientes);

            // ==================================================
            // PANEL INFERIOR → ESTADO / TOTAL
            // ==================================================
            Panel panelInfoVenta = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 70
            };

            lblEstadoVenta = new Label
            {
                Text = "Estado: -",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Dock = DockStyle.Top,
                ForeColor = Color.DimGray
            };

            lblTotal = new Label
            {
                Text = "Total: $0.00",
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Dock = DockStyle.Top
            };

            panelInfoVenta.Controls.Add(lblTotal);
            panelInfoVenta.Controls.Add(lblEstadoVenta);

            panelIzquierdo.Controls.Add(panelInfoVenta);

            // ==================================================
            // PANEL INFERIOR → BOTONES
            // ==================================================
            Panel panelBotones = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 160
            };
      
    

            Button btnNuevaVenta = CrearBoton("Nueva Venta");
            btnGuardarVenta = CrearBoton("Guardar Venta");
            btnPagarVenta = CrearBoton("Pagar Venta");
            Button btnVerVentas = CrearBoton("Ver Ventas");

            btnNuevaVenta.Click += btnNuevaVenta_Click;

    
            //panelBotones.Controls.SetChildIndex(btnNuevaVenta, 0); // lo pone arriba

            btnVerVentas.Click += btnVerVentas_Click;

          
            panelBotones.Controls.Add(btnVerVentas);
            panelBotones.Controls.Add(btnPagarVenta);
            panelBotones.Controls.Add(btnGuardarVenta);
            panelBotones.Controls.Add(btnNuevaVenta);
            panelIzquierdo.Controls.Add(panelBotones);

            // ==================================================
            // PANEL DERECHO → DETALLE DE LA VENTA
            // ==================================================
            dgvDetalleVenta = CrearGrid();

            // ==================================================
            // ARMAR SPLIT Y PESTAÑA
            // ==================================================
            split.Panel1.Controls.Add(panelIzquierdo);
            split.Panel2.Controls.Add(dgvDetalleVenta);

            tabVentas.Controls.Clear();
            tabVentas.Controls.Add(split);

            menuDetalleVenta = new ContextMenuStrip();
            ToolStripMenuItem eliminarItem = new ToolStripMenuItem("Eliminar producto");
            eliminarItem.Click += EliminarProducto_Click;

            menuDetalleVenta.Items.Add(eliminarItem);

            dgvDetalleVenta.ContextMenuStrip = menuDetalleVenta;
        }
        // ================= INVENTARIO =================
        private void InicializarInventario()
        {
            dgvInventario = CrearGrid();
            dgvInventario.Dock = DockStyle.Fill;

            lblTotalProductos = Etiqueta("Total productos: 0");
            lblTotalProductos.Dock = DockStyle.Bottom;

            tabInventario.Controls.Add(dgvInventario);
            tabInventario.Controls.Add(lblTotalProductos);
        }

        // ================= HELPERS =================
        private SplitContainer CrearSplit()
        {
            return new SplitContainer
            {
                Dock = DockStyle.Fill,
                SplitterDistance = 200
            };
        }

        private TableLayoutPanel CrearFormulario(string titulo)
        {
            TableLayoutPanel panel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new System.Windows.Forms.Padding(20),
                ColumnCount = 1,
                AutoScroll = true
            };

            panel.Controls.Add(new System.Windows.Forms.Label
            {
                Text = titulo,
                Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold),
                AutoSize = true
            });

            return panel;
        }

        private System.Windows.Forms.Label Etiqueta(string texto)
        {
            return new System.Windows.Forms.Label
            {
                Text = texto,
                AutoSize = true,
                Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold)
            };
        }

        private System.Windows.Forms.Button CrearBoton(string texto)
        {
            return new System.Windows.Forms.Button
            {
                Text = texto,
                Height = 40,
                Dock = DockStyle.Top
            };
        }

        private System.Windows.Forms.DataGridView CrearGrid()
        {
            return new System.Windows.Forms.DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
        }


    }
}